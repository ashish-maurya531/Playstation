from tkinter import*
from tkinter import messagebox 
from tkinter import ttk
import random
import time


print("main window called")
def start_game(choose):
    
    game.destroy()
    if choose == 1:
        import Animals
    elif choose == 2:
        import Computer
       
    elif choose == 3:
        import fruit
        
    elif choose == 4:
        import name
       
        
def start():
    
    
    global game
    game=Tk()
    game.title("JUMBBLED WORDS")
    game.geometry('800x533+200+100')
    game.resizable(0,0)
    g_canvas=Canvas(game,width=800,height=533,bg="red")
    g_canvas.place(x=0,y=0)
    gamefile1=PhotoImage(file="game.png")
    gamefile2=PhotoImage(file="correct2.png")
    gamefile3=PhotoImage(file="wrong.png")
    g_canvas.create_image(0,0,image=gamefile1,anchor=NW)
    
    
    
    username_entry=Entry(g_canvas,width=22,font=('Arial',20,'bold'),borderwidth=0,justify="center",fg="red")
    username_entry.place(x=250,y=230)

    label=g_canvas.create_text(400,160,text="       Enter your name to save your data",font=('Arial',20,'bold'),fill="blue")
    def option():
        btn1 = Button(text="Animals",width=14,borderwidth=0,font=('Arial',20,'bold'),bg="black",fg="green",
            activebackground="red",activeforeground="blue",cursor="hand2",command=lambda: start_game(1))
        btn1.place(x=300,y=200)
        btn2 = Button(text="Computer",width=14,borderwidth=0,font=('Arial',20,'bold'),bg="black",fg="green",
            activebackground="red",activeforeground="blue",cursor="hand2",command=lambda: start_game(2))
        btn2.place(x=300,y=260)
        btn3 = Button(text="Fruits",width=14,borderwidth=0,font=('Arial',20,'bold'),bg="black",fg="green",
            activebackground="red",activeforeground="blue",cursor="hand2",command=lambda: start_game(3))
        btn3.place(x=300,y=320)
        btn4 = Button(text="Celebrity",width=14,borderwidth=0,font=('Arial',20,'bold'),bg="black",fg="green",
            activebackground="red",activeforeground="blue",cursor="hand2",command=lambda: start_game(4))
        btn4.place(x=300,y=380)
    
    def save():
        save_username=str(username_entry.get()).upper()
        print(save_username)
        username_entry.destroy()
        butsave.destroy()
        g_canvas.itemconfigure(label,text="             Choose your topic:",font=('Arial',30,'bold'))
        option()
    butsave=Button(g_canvas,text="save",width=10,font=('Arial',15,'bold'),
        bg='black',fg="green",activebackground="red",activeforeground="blue",borderwidth=0,command=save)
    butsave.place(x=350,y=320)
    
    game.mainloop()





def play():
    intro.destroy()
    start()


def exitgame():
	quitgame=messagebox.askyesno("QUIT THE GAME","ARE YOU REALLY WANT TO QUIT THE GAME")
	if (quitgame):
		quit()
def led():
        
        
        led=Tk()
        led.title("JUMBBLED WORDS GAME LEADERBOARD")
        led.geometry('800x500+100+100')
        led.resizable(0,0)
        led.configure(bg="yellow")
        ledcanvas=Canvas(led,height=100,width=1010,bg="yellow")
        ledcanvas.pack()

        
        ledtext=ledcanvas.create_text(400,40,text="LEADERBOARD",font=('Arial',50,'bold underline'),fill="blue")
        lframe=Frame(led)
        lframe.pack(padx=20)
        tab=ttk.Treeview(lframe,columns=(1,2,3,4,5,6),show="headings",height=14)
        tab.pack(fill="both")
        tab.column(1,width=300)
        tab.column(2,width=100)
        tab.column(3,width=100)
        tab.column(4,width=100)
        tab.column(5,width=150)
        tab.heading(1,text="PLAYER NAME")
        tab.heading(2,text="ANIMALS NAME")
        tab.heading(3,text="COMPUTER PARTS NAME")
        tab.heading(4,text="FRUIT NAMES")
        tab.heading(5,text="CELEBRITY NAMES")
        tab.heading(6,text="TOTAL SCORE")
        
        def back1111():
            led.destroy()
        back=Button(led,text="BACK",bg="yellow",activebackground="red",fg='blue',activeforeground='blue',borderwidth=0,font=('Arial',30,'bold'),command=back1111)
        back.pack(pady=20)
        led.mainloop()
global file1,file2,file3,file4,intro
intro=Tk()
intro.geometry('701x455+300+100')
intro.title("JUMBBLED WORDS GAME")
intro.resizable(0,0)
c=Canvas(intro,height=450,width=701,bg="white")
c.place(x=0,y=0)
file1=PhotoImage(file="intro1.png")
file2=PhotoImage(file="play1.png")
file3=PhotoImage(file="leaderboard.png")
file4=PhotoImage(file='exit.png')
c.create_image(0,0,anchor=NW,image=file1)
bplay=Button(c,image=file2,anchor=NW,bg="white",activebackground="WHITE",borderwidth=0,command=play)
bplay.place(x=300,y=370)
    
bleaderboard=Button(c,image=file3,bg="white",activebackground="WHITE",borderwidth=0,command=led)
bleaderboard.place(x=100,y=370)

bexit=Button(c,image=file4,bg="white",activebackground="WHITE",borderwidth=0,command=exitgame)
bexit.place(x=500,y=370)
intro.mainloop()
'''    
def gameintro():
	global file1,file2,file3,file4,intro
	intro=Tk()
	intro.geometry('701x455+300+100')
	intro.title("JUMBBLED WORDS GAME")
	intro.resizable(0,0)
	c=Canvas(intro,height=450,width=701,bg="white")
	c.place(x=0,y=0)
	file1=PhotoImage(file="intro1.png")
	file2=PhotoImage(file="play1.png")
	file3=PhotoImage(file="leaderboard.png")
	file4=PhotoImage(file='exit.png')
	c.create_image(0,0,anchor=NW,image=file1)
	bplay=Button(c,image=file2,anchor=NW,bg="white",activebackground="WHITE",borderwidth=0,command=play)
	bplay.place(x=300,y=370)
	
	bleaderboard=Button(c,image=file3,bg="white",activebackground="WHITE",borderwidth=0,command=led)
	bleaderboard.place(x=100,y=370)

	bexit=Button(c,image=file4,bg="white",activebackground="WHITE",borderwidth=0,command=exitgame)
	bexit.place(x=500,y=370)
	intro.mainloop()
gameintro()
'''