from tkinter import*
from tkinter import messagebox
import random
import time
import threading
from threading import Timer

CELEBRITY_NAMES_WORD = ['DRBI', 'DGO', 'OENDYK', 'GFRIEFA', 'GLOILARTA', 'TAC', 'EHSOR', 'OLIN', 'MYOEKN', 'EEB', 'KDUC',
                'RGFO', 'TPNLEHEA', 'ORCDCIELO', 'POLNIHD', 'LARLIGO', 'EMSUO', 'EGTRI', 'ABRITB', 'ATR', ]

CELEBRITY_NAMES_ANSWER = ['BIRD', 'DOG', 'DONKEY', 'GIRAFFE', 'ALLIGATOR', 'CAT', 'HORSE', 'LION', 'MONKEY', 'BEE', 'DUCK',
                  'FROG', 'ELEPHANT', 'CROCODILE', 'DOLPHIN', 'GORILLA', 'MOUSE', 'TIGER', 'RABBIT', 'RAT', ]

CELEBRITY_NAMES_WORD2 =list(CELEBRITY_NAMES_WORD)



random_index=random.randrange(0,len(CELEBRITY_NAMES_WORD))
jword=CELEBRITY_NAMES_WORD2[random_index]
index_match=CELEBRITY_NAMES_WORD.index(jword)
CELEBRITY_NAMES_WORD2.remove(jword)



score_celebrity_names=0
click_on_answer=0
img_no=0
celebrity_names_game=Tk()
celebrity_names_game.title("JUMBULED WORDS => celebrity names")
celebrity_names_game.geometry('800x533+200+100')
celebrity_names_canvas=Canvas(celebrity_names_game,width=800,height=533,bg="red")
celebrity_names_canvas.place(x=0,y=0)
gamefile1=PhotoImage(file="game.png")
gamefile2=PhotoImage(file="correct2.png")
gamefile3=PhotoImage(file="wrong.png")

celebrity_names_canvas.create_image(0,0,image=gamefile1,anchor=NW)
def exit():
	qut=messagebox.askyesno("Exit the game","Do you really want to exit?")
	if (qut):
		quit()
def homepage():
	print("homepage clicked")
	gameover.destroy()
	import jumbledwords
def GAMEOVER():
	
	celebrity_names_game.destroy()
	global gamefile4,gamefile5,score_celebrity_names,gameover

	
	
	
	gameover=Tk()
	gameover.title("GAME OVER")
	gameover.geometry("520x300+400+200")
	gameover_canvas=Canvas(gameover,width=520,height=300,bg="white")
	gamefile4=PhotoImage(file="GAMEOVER3.png")
	gamefile5=PhotoImage(file="exitOVER.png")
	gamefile6=PhotoImage(file="homepage.png")
	gameover_canvas.create_image(0,0,image=gamefile4,anchor=NW)
	gameover_canvas.place(x=0,y=0)
	over_exit=Button(gameover_canvas,image=gamefile5,borderwidth=0,command=exit)
	over_exit.place(x=390,y=220)
	over_homepage=Button(gameover_canvas,image=gamefile6,borderwidth=0,command=homepage)
	over_homepage.place(x=50,y=220)
	gameover_canvas.create_text(250,250,text="You Scored: "+str(score_celebrity_names),font=('Arial',20,'bold'),fill="blue")

	gameover.mainloop()

score_label=celebrity_names_canvas.create_text(720,15,text="Score: "+str(score_celebrity_names),font=('Arial',20,'bold'),fill="blue")

useranswer_entry=Entry(celebrity_names_canvas,width=22,font=('Arial',23,'bold'),borderwidth=0,justify="center",fg="red")
useranswer_entry.place(x=240,y=230)

label=celebrity_names_canvas.create_text(410,180,text=jword,font=('Arial',40,'bold'),fill="blue")
def next_word():

	global random_index,jword,count,index_match,click_on_answer
	if len(CELEBRITY_NAMES_WORD2)==1:
			next_button.config(state=DISABLED)
			
	random_index=random.randrange(0,len(CELEBRITY_NAMES_WORD2))
	jword=CELEBRITY_NAMES_WORD2[random_index]
	index_match=CELEBRITY_NAMES_WORD.index(jword)
	CELEBRITY_NAMES_WORD2.remove(jword)
	celebrity_names_canvas.itemconfigure(label,text=jword)
	useranswer_entry.delete(0,END)
	
		

	try:
		celebrity_names_canvas.itemconfigure(answer_label,text='')
		answer_button.config(state=NORMAL)
		check_button.config(state=NORMAL)
		
		
	except:
		pass

	if (((click_on_answer==1) and (img_no==1)) or(img_no==1) ):
		celebrity_names_canvas.delete(correct_image)

	elif (((click_on_answer==1) and (img_no==2)) or(img_no==2)) :
		celebrity_names_canvas.delete(wrong_image)


answer_label=celebrity_names_canvas.create_text(702,460,text=" ",font=('Arial',13,'bold'),fill="blue")
def answer_check():
	global score_celebrity_names,answer_label,index_match,click_on_answer
	if (score_celebrity_names==0):
		if (len(CELEBRITY_NAMES_WORD2)==0):
			celebrity_names_canvas.itemconfigure(answer_label,text=CELEBRITY_NAMES_ANSWER[index_match],font=('Arial',20,'bold'),fill="green")
			answer_button.config(state=DISABLED)
			check_button.config(state=DISABLED)
			celebrity_names_game.after(1000,GAMEOVER)
		elif (len(CELEBRITY_NAMES_WORD2)!=0):
			celebrity_names_canvas.itemconfigure(answer_label,text="           sorry!\nscore your score is 0",font=('Arial',13,'bold'),fill="blue")
			print(len(CELEBRITY_NAMES_WORD2))
	else:
		score_celebrity_names-=1
		click_on_answer+=1
		celebrity_names_canvas.itemconfigure(score_label,text="Score: "+str(score_celebrity_names))
		celebrity_names_canvas.itemconfigure(answer_label,text=CELEBRITY_NAMES_ANSWER[index_match],font=('Arial',20,'bold'),fill="green")
		answer_button.config(state=DISABLED)
		check_button.config(state=DISABLED)
		if len(CELEBRITY_NAMES_WORD2)==0:
			print(len(CELEBRITY_NAMES_WORD2))
			next_button.config(state=DISABLED)
			print("game over")
			celebrity_names_game.after(1000,GAMEOVER)
			check_button.config(state=DISABLED)
			print("game over")
			
	'''if ((score_celebrity_names==0) and (len(CELEBRITY_NAMES_WORD2)==0)):
		print(score_celebrity_names)
		celebrity_names_canvas.itemconfigure(answer_label,text=CELEBRITY_NAMES_ANSWER[index_match],font=('Arial',20,'bold'),fill="green")
		answer_button.config(state=DISABLED)
		check_button.config(state=DISABLED)
		celebrity_names_game.after(1000,GAMEOVER)
	elif ((score_celebrity_names==0) and (len(CELEBRITY_NAMES_WORD2)!=0)):
		celebrity_names_canvas.itemconfigure(answer_label,text="           sorry!\nscore your score is 0",font=('Arial',13,'bold'),fill="blue")
		print(len(CELEBRITY_NAMES_WORD2))
		next_button.config(state=DISABLED)
		print("game over")
		celebrity_names_game.after(1000,next_word)'''
	


def check_answer():
	global score_celebrity_names,gamefile2,gamefile3,img_no,correct_image,wrong_image

	
		
	gamefile2=PhotoImage(file="correct2.png")
	gamefile3=PhotoImage(file="wrong.png")
	if len(useranswer_entry.get())==0:
		messagebox.showwarning("Warning!","              Invalid entry!\nYou have entered nothing in the box.")
	elif useranswer_entry.get()==(CELEBRITY_NAMES_ANSWER[index_match]).upper():
		score_celebrity_names+=1
		celebrity_names_canvas.itemconfigure(score_label,text="Score: "+str(score_celebrity_names))
		
		img_no=1
		correct_image=celebrity_names_canvas.create_image(670,245,image=gamefile2)
		if len(CELEBRITY_NAMES_WORD2)==0:
			print(len(CELEBRITY_NAMES_WORD2))
			next_button.config(state=DISABLED)
			print("game over")
			celebrity_names_game.after(500,GAMEOVER)
			
			
		else:
			celebrity_names_game.after(500,next_word)

	elif useranswer_entry.get()!=(str(CELEBRITY_NAMES_ANSWER[index_match])).upper():
		wrong_image=celebrity_names_canvas.create_image(670,245,image=gamefile3)
		img_no=2





check_button=Button(celebrity_names_canvas,text="Check",width=10,font=('Arial',15,'bold'),
	bg='black',fg="green",activebackground="red",activeforeground="blue",borderwidth=0,command=check_answer)
check_button.place(x=350,y=300)
next_button=Button(celebrity_names_canvas,text="next",width=10,font=('Arial',15,'bold'),
	bg='black',fg="green",activebackground="red",activeforeground="blue",borderwidth=0,command=next_word)
next_button.place(x=350,y=360)
answer_label_info=celebrity_names_canvas.create_text(500,520,text="For correct answer click here==>",font=('Arial',10,'bold'),fill="blue")
answer_button=Button(celebrity_names_canvas,text="Correct answer",width=15,font=('Arial',15,'bold'),
	bg='black',fg="green",activebackground="red",activeforeground="blue",borderwidth=0,command=answer_check)
answer_button.place(x=620,y=494)


celebrity_names_game.mainloop()
