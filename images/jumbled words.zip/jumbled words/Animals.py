from tkinter import*
from tkinter import messagebox
import random
import time
import threading
from threading import Timer

ANIMALS_WORD = ['DRBI', 'DGO', 'OENDYK', 'GFRIEFA', 'GLOILARTA', 'TAC', 'EHSOR', 'OLIN', 'MYOEKN', 'EEB', 'KDUC',
                'RGFO', 'TPNLEHEA', 'ORCDCIELO', 'POLNIHD', 'LARLIGO', 'EMSUO', 'EGTRI', 'ABRITB', 'ATR', ]

ANIMALS_ANSWER = ['BIRD', 'DOG', 'DONKEY', 'GIRAFFE', 'ALLIGATOR', 'CAT', 'HORSE', 'LION', 'MONKEY', 'BEE', 'DUCK',
                  'FROG', 'ELEPHANT', 'CROCODILE', 'DOLPHIN', 'GORILLA', 'MOUSE', 'TIGER', 'RABBIT', 'RAT', ]

ANIMALS_WORD2 =list(ANIMALS_WORD)



random_index=random.randrange(0,len(ANIMALS_WORD))
jword=ANIMALS_WORD2[random_index]
index_match=ANIMALS_WORD.index(jword)
ANIMALS_WORD2.remove(jword)



score_animal=0
click_on_answer=0
img_no=0
animal_game=Tk()
animal_game.title("JUMBULED WORDS => ANIMAL")
animal_game.geometry('800x533+200+100')
animal_canvas=Canvas(animal_game,width=800,height=533,bg="red")
animal_canvas.place(x=0,y=0)
gamefile1=PhotoImage(file="game.png")
gamefile2=PhotoImage(file="correct2.png")
gamefile3=PhotoImage(file="wrong.png")

animal_canvas.create_image(0,0,image=gamefile1,anchor=NW)
def exit():
	qut=messagebox.askyesno("Exit the game","Do you really want to exit?")
	if (qut):
		quit()
def homepage():
	print("homepage clicked")
	gameover.destroy()
	import jumbledwords
def GAMEOVER():
	
	animal_game.destroy()
	global gamefile4,gamefile5,score_animal,gameover

	
	
	
	gameover=Tk()
	gameover.title("GAME OVER")
	gameover.geometry("520x300+400+200")
	gameover_canvas=Canvas(gameover,width=520,height=300,bg="white")
	gamefile4=PhotoImage(file="GAMEOVER3.png")
	gamefile5=PhotoImage(file="exitOVER.png")
	gamefile6=PhotoImage(file="homepage.png")
	gameover_canvas.create_image(0,0,image=gamefile4,anchor=NW)
	gameover_canvas.place(x=0,y=0)
	over_exit=Button(gameover_canvas,image=gamefile5,borderwidth=0,command=exit)
	over_exit.place(x=390,y=220)
	over_homepage=Button(gameover_canvas,image=gamefile6,borderwidth=0,command=homepage)
	over_homepage.place(x=50,y=220)
	gameover_canvas.create_text(250,250,text="You Scored: "+str(score_animal),font=('Arial',20,'bold'),fill="blue")

	gameover.mainloop()


score_label=animal_canvas.create_text(720,15,text="Score: "+str(score_animal),font=('Arial',20,'bold'),fill="blue")

useranswer_entry=Entry(animal_canvas,width=22,font=('Arial',23,'bold'),borderwidth=0,justify="center",fg="red")
useranswer_entry.place(x=240,y=230)

label=animal_canvas.create_text(410,180,text=jword,font=('Arial',40,'bold'),fill="blue")
def next_word():

	global random_index,jword,count,index_match,click_on_answer
	if len(ANIMALS_WORD2)==1:
			next_button.config(state=DISABLED)
			
	random_index=random.randrange(0,len(ANIMALS_WORD2))
	jword=ANIMALS_WORD2[random_index]
	index_match=ANIMALS_WORD.index(jword)
	ANIMALS_WORD2.remove(jword)
	animal_canvas.itemconfigure(label,text=jword)
	useranswer_entry.delete(0,END)
	
		

	try:
		animal_canvas.itemconfigure(answer_label,text='')
		answer_button.config(state=NORMAL)
		check_button.config(state=NORMAL)
		
		
	except:
		pass

	if (((click_on_answer==1) and (img_no==1)) or(img_no==1) ):
		animal_canvas.delete(correct_image)

	elif (((click_on_answer==1) and (img_no==2)) or(img_no==2)) :
		animal_canvas.delete(wrong_image)


answer_label=animal_canvas.create_text(702,460,text=" ",font=('Arial',13,'bold'),fill="blue")
def answer_check():
	global score_animal,answer_label,index_match,click_on_answer
	if (score_animal==0):
		if (len(ANIMALS_WORD2)==0):
			animal_canvas.itemconfigure(answer_label,text=ANIMALS_ANSWER[index_match],font=('Arial',20,'bold'),fill="green")
			answer_button.config(state=DISABLED)
			check_button.config(state=DISABLED)
			animal_game.after(1000,GAMEOVER)
		elif (len(ANIMALS_WORD2)!=0):
			animal_canvas.itemconfigure(answer_label,text="           sorry!\nscore your score is 0",font=('Arial',13,'bold'),fill="blue")
			print(len(ANIMALS_WORD2))
	else:
		score_animal-=1
		click_on_answer+=1
		animal_canvas.itemconfigure(score_label,text="Score: "+str(score_animal))
		animal_canvas.itemconfigure(answer_label,text=ANIMALS_ANSWER[index_match],font=('Arial',20,'bold'),fill="green")
		answer_button.config(state=DISABLED)
		check_button.config(state=DISABLED)
		if len(ANIMALS_WORD2)==0:
			print(len(ANIMALS_WORD2))
			next_button.config(state=DISABLED)
			print("game over")
			animal_game.after(1000,GAMEOVER)
			check_button.config(state=DISABLED)
			print("game over")
			
	'''if ((score_animal==0) and (len(ANIMALS_WORD2)==0)):
		print(score_animal)
		animal_canvas.itemconfigure(answer_label,text=ANIMALS_ANSWER[index_match],font=('Arial',20,'bold'),fill="green")
		answer_button.config(state=DISABLED)
		check_button.config(state=DISABLED)
		animal_game.after(1000,GAMEOVER)
	elif ((score_animal==0) and (len(ANIMALS_WORD2)!=0)):
		animal_canvas.itemconfigure(answer_label,text="           sorry!\nscore your score is 0",font=('Arial',13,'bold'),fill="blue")
		print(len(ANIMALS_WORD2))
		next_button.config(state=DISABLED)
		print("game over")
		animal_game.after(1000,next_word)'''
	


def check_answer():
	global score_animal,gamefile2,gamefile3,img_no,correct_image,wrong_image

	
		
	gamefile2=PhotoImage(file="correct2.png")
	gamefile3=PhotoImage(file="wrong.png")
	if len(useranswer_entry.get())==0:
		messagebox.showwarning("Warning!","              Invalid entry!\nYou have entered nothing in the box.")
	elif useranswer_entry.get()==(ANIMALS_ANSWER[index_match]).upper():
		score_animal+=1
		animal_canvas.itemconfigure(score_label,text="Score: "+str(score_animal))
		
		img_no=1
		correct_image=animal_canvas.create_image(670,245,image=gamefile2)
		if len(ANIMALS_WORD2)==0:
			print(len(ANIMALS_WORD2))
			next_button.config(state=DISABLED)
			print("game over")
			animal_game.after(500,GAMEOVER)
			
			
		else:
			animal_game.after(500,next_word)

	elif useranswer_entry.get()!=(str(ANIMALS_ANSWER[index_match])).upper():
		wrong_image=animal_canvas.create_image(670,245,image=gamefile3)
		img_no=2





check_button=Button(animal_canvas,text="Check",width=10,font=('Arial',15,'bold'),
	bg='black',fg="green",activebackground="red",activeforeground="blue",borderwidth=0,command=check_answer)
check_button.place(x=350,y=300)
next_button=Button(animal_canvas,text="next",width=10,font=('Arial',15,'bold'),
	bg='black',fg="green",activebackground="red",activeforeground="blue",borderwidth=0,command=next_word)
next_button.place(x=350,y=360)
answer_label_info=animal_canvas.create_text(500,520,text="For correct answer click here==>",font=('Arial',10,'bold'),fill="blue")
answer_button=Button(animal_canvas,text="Correct answer",width=15,font=('Arial',15,'bold'),
	bg='black',fg="green",activebackground="red",activeforeground="blue",borderwidth=0,command=answer_check)
answer_button.place(x=620,y=494)


animal_game.mainloop()
